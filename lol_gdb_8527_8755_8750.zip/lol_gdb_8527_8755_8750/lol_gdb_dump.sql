-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: lol_gdb
-- ------------------------------------------------------
-- Server version	5.5.57-MariaDB


DROP SCHEMA IF EXISTS `LoL_gdb`;
CREATE SCHEMA `LoL_gdb`;
USE `LoL_gdb`;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ability`
--


DROP TABLE IF EXISTS `ability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ability` (
  `Ability_Name` varchar(25) NOT NULL,
  `Utility` enum('stun','knock_up','charm','fear') DEFAULT NULL,
  `Champ_Name` varchar(25) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Cooldown` int(11) DEFAULT NULL,
  `Damage` int(11) DEFAULT NULL,
  PRIMARY KEY (`Ability_Name`,`Champ_Name`),
  KEY `Champ_Name_idx` (`Champ_Name`),
  CONSTRAINT `Champ_Name` FOREIGN KEY (`Champ_Name`) REFERENCES `champion` (`Champ_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ability`
--

LOCK TABLES `ability` WRITE;
/*!40000 ALTER TABLE `ability` DISABLE KEYS */;
INSERT INTO `ability` (`Ability_Name`, `Utility`, `Champ_Name`, `Description`, `Cooldown`, `Damage`) VALUES ('e','charm','ahri','Once upon a time',7,40),('e','charm','fidlesticks','Once upon a time',5,30),('q','fear','ahri','Once upon a time',4,100),('q','fear','fidlesticks','Once upon a time',3,20),('w','stun','fidlesticks','Once upon a time',4,40);
/*!40000 ALTER TABLE `ability` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Ability_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`ability`
FOR EACH ROW
BEGIN

if (new.Utility!="stun" and new.Utility != "knock_up" and new.Utility != "charm" and new.Utility != "fear") then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.cooldown<0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.damage<0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Ability_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`ability`
FOR EACH ROW
BEGIN

if (new.Utility!="stun" and new.Utility != "knock_up" and new.Utility != "charm" and new.Utility != "fear") then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.cooldown<0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.damage<0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ability_lvl`
--

DROP TABLE IF EXISTS `ability_lvl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ability_lvl` (
  `level_ID` int(11) NOT NULL,
  `ability_name` varchar(25) NOT NULL,
  `ap_ratio` decimal(1,1) DEFAULT NULL,
  `ad_ratio` decimal(1,1) DEFAULT NULL,
  `health_ratio` decimal(1,1) DEFAULT NULL,
  `mana_ratio` decimal(1,1) DEFAULT NULL,
  PRIMARY KEY (`level_ID`,`ability_name`),
  KEY `ability_foreign_idx` (`ability_name`),
  CONSTRAINT `ability_foreign` FOREIGN KEY (`ability_name`) REFERENCES `ability` (`Ability_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ability_lvl`
--

LOCK TABLES `ability_lvl` WRITE;
/*!40000 ALTER TABLE `ability_lvl` DISABLE KEYS */;
INSERT INTO `ability_lvl` (`level_ID`, `ability_name`, `ap_ratio`, `ad_ratio`, `health_ratio`, `mana_ratio`) VALUES (1,'q',0.2,0.6,0.5,0.9),(3,'e',0.4,0.2,0.9,0.1),(4,'w',0.9,0.1,0.6,0.4),(5,'q',0.6,0.4,0.2,0.6),(17,'w',0.1,0.6,0.4,0.2);
/*!40000 ALTER TABLE `ability_lvl` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`ability_lvl_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`ability_lvl`
FOR EACH ROW
BEGIN
	if (new.ap_ratio < 0 or new.ad_ratio< 0 or new.health_ratio < 0 or new.mana_ratio <0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`ability_lvl_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`ability_lvl`
FOR EACH ROW
BEGIN
	if (new.ap_ratio < 0 or new.ad_ratio< 0 or new.health_ratio < 0 or new.mana_ratio <0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ability_progress`
--

DROP TABLE IF EXISTS `ability_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ability_progress` (
  `level_ID` int(11) NOT NULL,
  `ability_name` varchar(25) NOT NULL,
  `game_ID` int(11) NOT NULL,
  `player_name` varchar(25) NOT NULL,
  `orders` int(11) NOT NULL,
  PRIMARY KEY (`level_ID`,`ability_name`,`game_ID`,`player_name`),
  KEY `game_foreign_progress_idx` (`game_ID`,`player_name`),
  CONSTRAINT `game_foreign_progress` FOREIGN KEY (`game_ID`, `player_name`) REFERENCES `game` (`id`, `Player_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `lvl_foreign_progress` FOREIGN KEY (`level_ID`, `ability_name`) REFERENCES `ability_lvl` (`level_ID`, `ability_name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ability_progress`
--

LOCK TABLES `ability_progress` WRITE;
/*!40000 ALTER TABLE `ability_progress` DISABLE KEYS */;
INSERT INTO `ability_progress` (`level_ID`, `ability_name`, `game_ID`, `player_name`, `orders`) VALUES (1,'q',6,'Gianakos',4),(3,'e',6,'Psomaki4',2),(4,'w',8,'lulkappa2017',3),(5,'q',7,'hide on bush',4),(17,'w',8,'lulkappa2017',1);
/*!40000 ALTER TABLE `ability_progress` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`ability_progress_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`ability_progress`
FOR EACH ROW
BEGIN
	if (new.orders < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`ability_progress_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`ability_progress`
FOR EACH ROW
BEGIN
	if (new.orders < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `challenger_picks`
--

DROP TABLE IF EXISTS `challenger_picks`;
/*!50001 DROP VIEW IF EXISTS `challenger_picks`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `challenger_picks` AS SELECT 
 1 AS `id`,
 1 AS `Creeps_killed`,
 1 AS `Kills`,
 1 AS `Deaths`,
 1 AS `Assists`,
 1 AS `Duration`,
 1 AS `Dates`,
 1 AS `Team_side`,
 1 AS `Result`,
 1 AS `Position`,
 1 AS `Champ_Name`,
 1 AS `Player_Name`,
 1 AS `Champ_Level`,
 1 AS `User_Name`,
 1 AS `Level`,
 1 AS `Rank`,
 1 AS `Age`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `champ_lvl`
--

DROP TABLE IF EXISTS `champ_lvl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `champ_lvl` (
  `level_ID` int(11) NOT NULL,
  `champ_name` varchar(25) NOT NULL,
  `ap_ratio` decimal(1,1) DEFAULT NULL,
  `health_ratio` decimal(1,1) DEFAULT NULL,
  `mana_ratio` decimal(1,1) DEFAULT NULL,
  `armor_ratio` decimal(1,1) DEFAULT NULL,
  `mr_ratio` decimal(1,1) DEFAULT NULL,
  `as_ratio` decimal(1,1) DEFAULT NULL,
  `ad_ratio` decimal(1,1) DEFAULT NULL,
  PRIMARY KEY (`level_ID`,`champ_name`),
  KEY `champion_foreign_lvl_idx` (`champ_name`),
  CONSTRAINT `champion_foreign_lvl` FOREIGN KEY (`champ_name`) REFERENCES `champion` (`Champ_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `champ_lvl`
--

LOCK TABLES `champ_lvl` WRITE;
/*!40000 ALTER TABLE `champ_lvl` DISABLE KEYS */;
INSERT INTO `champ_lvl` (`level_ID`, `champ_name`, `ap_ratio`, `health_ratio`, `mana_ratio`, `armor_ratio`, `mr_ratio`, `as_ratio`, `ad_ratio`) VALUES (1,'ahri',0.2,0.6,0.5,0.9,0.6,0.3,0.4),(3,'nasus',0.4,0.2,0.9,0.1,0.4,0.2,0.6),(4,'darius',0.9,0.1,0.6,0.4,0.9,0.1,0.2),(5,'fidlesticks',0.6,0.4,0.2,0.6,0.4,0.2,0.5),(10,'nasus',0.2,0.5,0.2,0.5,0.2,0.1,0.4),(17,'veigar',0.1,0.6,0.4,0.2,0.1,0.6,0.9);
/*!40000 ALTER TABLE `champ_lvl` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`champ_lvl_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`champ_lvl`
FOR EACH ROW
BEGIN
	if (new.ap_ratio < 0 or new.health_ratio < 0 or new.mana_ratio < 0 or new.armor_ratio < 0 or new.mr_ratio < 0 or new.ad_ratio < 0 or new.as_ratio < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`champ_lvl_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`champ_lvl`
FOR EACH ROW
BEGIN
	if (new.ap_ratio < 0 or new.health_ratio < 0 or new.mana_ratio < 0 or new.armor_ratio < 0 or new.mr_ratio < 0 or new.ad_ratio < 0 or new.as_ratio < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `champion`
--

DROP TABLE IF EXISTS `champion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `champion` (
  `Champ_Name` varchar(25) NOT NULL,
  `Lore` varchar(100) NOT NULL,
  `Role` enum('Support','Assasin','Tank','Mage','Ranged') NOT NULL,
  `Health` int(11) DEFAULT NULL,
  `Mana` int(11) DEFAULT NULL,
  `Attack_Damage` int(11) DEFAULT NULL,
  `Ability_Power` int(11) DEFAULT NULL,
  `Armor` int(11) DEFAULT NULL,
  `Magic_Resistance` int(11) DEFAULT NULL,
  `Attack_Speed` decimal(1,1) DEFAULT NULL,
  PRIMARY KEY (`Champ_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `champion`
--

LOCK TABLES `champion` WRITE;
/*!40000 ALTER TABLE `champion` DISABLE KEYS */;
INSERT INTO `champion` (`Champ_Name`, `Lore`, `Role`, `Health`, `Mana`, `Attack_Damage`, `Ability_Power`, `Armor`, `Magic_Resistance`, `Attack_Speed`) VALUES ('ahri','Once upon..','Mage',750,500,30,54,42,45,0.4),('darius','Once upon..','Tank',1300,400,40,42,20,34,0.3),('fidlesticks','Once upon..','Mage',1000,300,20,40,30,23,0.3),('nasus','Once upon..','Support',500,600,100,56,84,45,0.5),('veigar','Once upon..','Assasin',800,700,40,67,123,56,0.6);
/*!40000 ALTER TABLE `champion` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Champion_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`champion`
FOR EACH ROW
BEGIN

#antistoixa gia ta ipolipa features
if (new.Health<0 or new.Mana<0) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.Role!='Support' and new.Role!='Assasin' and new.Role!='Mage'and new.Role!='Tank' and new.Role!='Ranged') then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Champion_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`champion`
FOR EACH ROW
BEGIN

if (new.Health<0 or new.Mana<0) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

if (new.Role!='Support' and new.Role!='Assasin' and new.Role!='Mage'and new.Role!='Tank' and new.Role!='Ranged') then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `champion_counters_champion`
--

DROP TABLE IF EXISTS `champion_counters_champion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `champion_counters_champion` (
  `Champion_picked` varchar(25) NOT NULL,
  `Champion_Countered` varchar(25) NOT NULL,
  PRIMARY KEY (`Champion_picked`,`Champion_Countered`),
  KEY `Champion_Countered_idx` (`Champion_Countered`),
  CONSTRAINT `Champion_Countered` FOREIGN KEY (`Champion_Countered`) REFERENCES `champion` (`Champ_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Champion_picked` FOREIGN KEY (`Champion_picked`) REFERENCES `champion` (`Champ_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `champion_counters_champion`
--

LOCK TABLES `champion_counters_champion` WRITE;
/*!40000 ALTER TABLE `champion_counters_champion` DISABLE KEYS */;
INSERT INTO `champion_counters_champion` (`Champion_picked`, `Champion_Countered`) VALUES ('ahri','fidlesticks'),('darius','nasus'),('fidlesticks','ahri'),('nasus','veigar'),('veigar','darius');
/*!40000 ALTER TABLE `champion_counters_champion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `champion_ranking`
--

DROP TABLE IF EXISTS `champion_ranking`;
/*!50001 DROP VIEW IF EXISTS `champion_ranking`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `champion_ranking` AS SELECT 
 1 AS `KDA`,
 1 AS `Champion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `date_player_comb`
--

DROP TABLE IF EXISTS `date_player_comb`;
/*!50001 DROP VIEW IF EXISTS `date_player_comb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `date_player_comb` AS SELECT 
 1 AS `player_name`,
 1 AS `dates`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `dates_of_interest`
--

DROP TABLE IF EXISTS `dates_of_interest`;
/*!50001 DROP VIEW IF EXISTS `dates_of_interest`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `dates_of_interest` AS SELECT 
 1 AS `dates`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game` (
  `id` int(11) NOT NULL,
  `Creeps_killed` int(11) DEFAULT NULL,
  `Kills` int(11) DEFAULT NULL,
  `Deaths` int(11) DEFAULT NULL,
  `Assists` int(11) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `Dates` date NOT NULL,
  `Team_side` enum('red','blue') DEFAULT NULL,
  `Result` enum('win','lose') DEFAULT NULL,
  `Position` enum('Adc','Top','Mid','Jungle','Bot') NOT NULL,
  `Champ_Name` varchar(25) NOT NULL,
  `Player_Name` varchar(25) NOT NULL,
  `Champ_Level` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Player_Name`),
  KEY `user_foreign_idx` (`Player_Name`),
  KEY `Champion_foreign_idx` (`Champ_Level`),
  CONSTRAINT `Champion_foreign` FOREIGN KEY (`Champ_Level`) REFERENCES `champ_lvl` (`level_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_foreign` FOREIGN KEY (`Player_Name`) REFERENCES `player` (`User_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` (`id`, `Creeps_killed`, `Kills`, `Deaths`, `Assists`, `Duration`, `Dates`, `Team_side`, `Result`, `Position`, `Champ_Name`, `Player_Name`, `Champ_Level`) VALUES (6,343,7,8,0,456,'2018-10-24','red','win','Top','veigar','Gianakos',17),(6,245,17,9,12,3456,'2018-10-24','red','win','Adc','nasus','Midasthegreat',3),(6,345,10,12,8,234,'2018-10-24','blue','lose','Adc','darius','Psomaki4',4),(7,123,23,12,23,4566,'2018-10-24','red','win','Mid','nasus','hide on bush',10),(8,546,4,12,2,456,'2018-11-01','blue','lose','Jungle','fiddlesticks','lulkappa2017',5),(9,455,4,6,2,456,'2018-11-02','red','lose','Top','nasus','lulkappa2017',10),(9,456,3,4,53,346,'2018-11-02','blue','win','Top','ahri','Midasthegreat',1),(10,683,9,23,21,4589,'2018-11-04','red','win','Jungle','veigar','Midasthegreat',3),(11,543,8,6,20,456,'2018-11-01','blue','lose','Mid','veigar','Midasthegreat',17),(12,456,12,2,12,123,'2018-02-12','blue','win','Top','darius','Gianakos',4),(12,677,9,8,6,456,'2018-11-04','red','lose','Jungle','fiddlesticks','lulkappa2017',5),(13,456,12,2,12,123,'2018-02-12','blue','lose','Top','veigar','Gianakos',17),(13,456,1,2,12,123,'2018-02-12','red','win','Top','ahri','Midasthegreat',1),(14,894,1,3,7,263,'2018-02-12','blue','lose','Mid','veigar','hide on bush',17),(15,894,1,3,7,263,'2018-02-12','blue','lose','Mid','veigar','hide on bush',17),(15,456,1,2,12,123,'2018-02-12','red','win','Mid','ahri','Midasthegreat',1),(16,487,1,2,12,123,'2018-02-12','red','lose','Mid','ahri','Midasthegreat',10);
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Game_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`game`
FOR EACH ROW
BEGIN
	if (new.Champ_Level < 0 or new.Duration < 0 or new.Kills < 0 or new.Deaths < 0 or new.Assists < 0 or new.Creeps_killed < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
    if (new.Position != 'Mid' and new.Position != 'Abc' and new.Position != 'Jungle' and new.Position != 'Top')  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Game_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`game`
FOR EACH ROW
BEGIN
	if (new.Champ_Level < 0 or new.Duration < 0 or new.Kills < 0 or new.Deaths < 0 or new.Assists < 0 or new.Creeps_killed < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
    if (new.Position != 'Mid' and new.Position != 'Adc' and new.Position != 'Jungle' and new.Position != 'Top')  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `game_has_item`
--

DROP TABLE IF EXISTS `game_has_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_has_item` (
  `game_ID` int(11) NOT NULL,
  `player_name` varchar(25) NOT NULL,
  `item_name` varchar(25) NOT NULL,
  PRIMARY KEY (`game_ID`,`player_name`,`item_name`),
  KEY `Item_foreign_idx` (`item_name`),
  CONSTRAINT `Game_foreign_in_has` FOREIGN KEY (`game_ID`, `player_name`) REFERENCES `game` (`id`, `Player_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Item_foreign` FOREIGN KEY (`item_name`) REFERENCES `item` (`Item_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_has_item`
--

LOCK TABLES `game_has_item` WRITE;
/*!40000 ALTER TABLE `game_has_item` DISABLE KEYS */;
INSERT INTO `game_has_item` (`game_ID`, `player_name`, `item_name`) VALUES (6,'Gianakos','long sword'),(6,'Psomaki4','duskblade'),(6,'Psomaki4','ruby crystal'),(7,'hide on bush','warmogs'),(8,'lulkappa2017','zeal');
/*!40000 ALTER TABLE `game_has_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_has_runes`
--

DROP TABLE IF EXISTS `game_has_runes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_has_runes` (
  `game_ID` int(11) NOT NULL,
  `player_name` varchar(25) NOT NULL,
  `rune_name` varchar(25) NOT NULL,
  PRIMARY KEY (`game_ID`,`player_name`,`rune_name`),
  KEY `rune_foreign_has_idx` (`rune_name`),
  CONSTRAINT `game_foreign_has` FOREIGN KEY (`game_ID`, `player_name`) REFERENCES `game` (`id`, `Player_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `rune_foreign_has` FOREIGN KEY (`rune_name`) REFERENCES `rune` (`Rune_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_has_runes`
--

LOCK TABLES `game_has_runes` WRITE;
/*!40000 ALTER TABLE `game_has_runes` DISABLE KEYS */;
INSERT INTO `game_has_runes` (`game_ID`, `player_name`, `rune_name`) VALUES (6,'Gianakos','conditioning'),(6,'Psomaki4','Coquar '),(6,'Psomaki4','triumph'),(7,'hide on bush','unfliching'),(8,'lulkappa2017','unfliching');
/*!40000 ALTER TABLE `game_has_runes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_has_spell`
--

DROP TABLE IF EXISTS `game_has_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_has_spell` (
  `Game_ID` int(11) NOT NULL,
  `Player_Name` varchar(25) NOT NULL,
  `Spell_Name` varchar(25) NOT NULL,
  PRIMARY KEY (`Game_ID`,`Player_Name`,`Spell_Name`),
  KEY `Spell_foreign_idx` (`Spell_Name`),
  CONSTRAINT `Game_foreign` FOREIGN KEY (`Game_ID`, `Player_Name`) REFERENCES `game` (`id`, `Player_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Spell_foreign` FOREIGN KEY (`Spell_Name`) REFERENCES `spell` (`Spell_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_has_spell`
--

LOCK TABLES `game_has_spell` WRITE;
/*!40000 ALTER TABLE `game_has_spell` DISABLE KEYS */;
INSERT INTO `game_has_spell` (`Game_ID`, `Player_Name`, `Spell_Name`) VALUES (6,'Gianakos','barrier'),(6,'Midasthegreat','Flash'),(6,'Psomaki4','Flash'),(7,'hide on bush','Flash'),(7,'hide on bush','Teleport'),(8,'lulkappa2017','Flash'),(8,'lulkappa2017','Ignite');
/*!40000 ALTER TABLE `game_has_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `Item_Name` varchar(25) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Cost` int(11) NOT NULL,
  `Tenacity` decimal(1,1) DEFAULT NULL,
  `Critical` decimal(1,1) DEFAULT NULL,
  `Lifesteal` decimal(1,1) DEFAULT NULL,
  `Cooldown` int(11) DEFAULT NULL,
  `Category` enum('Offensive','Defensive','Utility') DEFAULT NULL,
  `Health` int(11) DEFAULT NULL,
  `Mana` int(11) DEFAULT NULL,
  `Attack_Damage` int(11) DEFAULT NULL,
  `Ability_Power` int(11) DEFAULT NULL,
  `Armor` int(11) DEFAULT NULL,
  `Magic_Resistance` int(11) DEFAULT NULL,
  `Attack_Speed` decimal(1,1) DEFAULT NULL,
  PRIMARY KEY (`Item_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` (`Item_Name`, `Description`, `Cost`, `Tenacity`, `Critical`, `Lifesteal`, `Cooldown`, `Category`, `Health`, `Mana`, `Attack_Damage`, `Ability_Power`, `Armor`, `Magic_Resistance`, `Attack_Speed`) VALUES ('duskblade','Gives Damage',1800,0.3,0.1,0.3,60,'Offensive',0,0,50,0,0,0,0.0),('long sword','Gives Damage',300,0.1,0.2,0.1,0,'Offensive',0,0,10,0,0,10,0.0),('ruby crystal','Gives life',400,0.4,0.4,0.5,0,'Defensive',100,0,0,0,30,12,0.0),('warmogs','Gives life',2500,0.5,0.5,0.6,8,'Defensive',500,0,0,0,50,15,0.0),('zeal','Gives critical',500,0.2,0.2,0.2,0,'Offensive',0,0,0,0,10,20,0.1);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Item_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`item`
FOR EACH ROW
BEGIN
	if (new.Cost < 0 or new.Tenacity < 0 or new.Critical < 0 or new.Cooldown < 0 or new.Mana < 0 or new.Health < 0 or new.Attack_Damage < 0 or new.Lifesteal < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
    
    if (new.Ability_Power < 0 or new.Magic_Resistance < 0 or new.Armor < 0 or new.Attack_Speed < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
    
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Item_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`item`
FOR EACH ROW
BEGIN
	if (new.Cost < 0 or new.Tenacity < 0 or new.Critical < 0 or new.Cooldown < 0 or new.Mana < 0 or new.Health < 0 or new.Attack_Damage or new.Lifesteal)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
    
    if (new.Ability_Power < 0 or new.Magic_Resistance < 0 or new.Armor < 0 or new.Attack_Speed < 0)  then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `item_forges_item`
--

DROP TABLE IF EXISTS `item_forges_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_forges_item` (
  `Forged_item_name` varchar(25) NOT NULL,
  `Component` varchar(25) NOT NULL,
  `Multiplicity` int(11) DEFAULT NULL,
  PRIMARY KEY (`Forged_item_name`,`Component`),
  KEY `Component_idx` (`Component`),
  CONSTRAINT `Component` FOREIGN KEY (`Component`) REFERENCES `item` (`Item_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Forged_item_name` FOREIGN KEY (`Forged_item_name`) REFERENCES `item` (`Item_Name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_forges_item`
--

LOCK TABLES `item_forges_item` WRITE;
/*!40000 ALTER TABLE `item_forges_item` DISABLE KEYS */;
INSERT INTO `item_forges_item` (`Forged_item_name`, `Component`, `Multiplicity`) VALUES ('duskblade','long sword',3),('duskblade','zeal',1),('warmogs','ruby crystal',1),('zeal','long sword',2);
/*!40000 ALTER TABLE `item_forges_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Item_Forges_Item_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`item_forges_item`
FOR EACH ROW
BEGIN

if (new.multiplicity < 0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Item_Forges_Item_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`item_forges_item`
FOR EACH ROW
BEGIN

if (new.multiplicity < 0 ) then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `matchups`
--

DROP TABLE IF EXISTS `matchups`;
/*!50001 DROP VIEW IF EXISTS `matchups`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `matchups` AS SELECT 
 1 AS `champ_red`,
 1 AS `champ_blue`,
 1 AS `Position`,
 1 AS `result`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player` (
  `User_Name` varchar(25) NOT NULL,
  `Level` int(11) NOT NULL,
  `Rank` enum('Bronze','Silver','Gold','Playtinum','Diamond','Master','Challenger') DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` (`User_Name`, `Level`, `Rank`, `Age`) VALUES ('Gianakos',2,'Bronze',11),('hide on bush',129,'Challenger',14),('lulkappa2017',9,'Gold',12),('Midasthegreat',56,'Master',22),('pinkward',154,'Master',25),('pokopokos',39,'Gold',27),('psomaki4',95,'Bronze',22);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Player_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`player`
FOR EACH ROW
BEGIN
    if( new.Rank != 'Bronze' and new.Rank != 'Gold' and new.Rank != 'Playtinum' and new.Rank != 'Diamond' and new.Rank != 'Master' and new.Rank != 'Challenger') Then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Player_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`player`
FOR EACH ROW
BEGIN
	 if( new.Rank != 'Bronze' and new.Rank != 'Gold' and new.Rank != 'Playtinum' and new.Rank != 'Diamond' and new.Rank != 'Master' and new.Rank != 'Challenger') Then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `rune`
--

DROP TABLE IF EXISTS `rune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rune` (
  `Rune_Name` varchar(25) NOT NULL,
  `Type` enum('Primary','Secondary') DEFAULT NULL,
  `Description` varchar(100) NOT NULL,
  `Cooldown` int(11) DEFAULT NULL,
  `Damage` enum('Physical','Magical','True') DEFAULT NULL,
  PRIMARY KEY (`Rune_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rune`
--

LOCK TABLES `rune` WRITE;
/*!40000 ALTER TABLE `rune` DISABLE KEYS */;
INSERT INTO `rune` (`Rune_Name`, `Type`, `Description`, `Cooldown`, `Damage`) VALUES ('conditioning','Secondary','Gain Armor and MR',10,'Physical'),('Coquar ','Primary','Gives you damage',4,'True'),('triumph','Primary','Gives you Health',0,'Physical'),('unfliching','Secondary','Gain Tenacity',6,'Magical');
/*!40000 ALTER TABLE `rune` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Rune_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`rune`
FOR EACH ROW
BEGIN

if (new.Type!="Primary" and new.Type != "Secondary") then
 signal sqlstate '45000' set message_text = 'invalid data';
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Rune_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`rune`
FOR EACH ROW
BEGIN
	if (new.Type!="Primary" and new.Type != "Secondary" and new.Damage != 'Physical' and new.Damage != 'Magical' and new.Damage != 'True') then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `spell`
--

DROP TABLE IF EXISTS `spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spell` (
  `Spell_Name` varchar(25) NOT NULL,
  `Cooldown` int(11) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Spell_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spell`
--

LOCK TABLES `spell` WRITE;
/*!40000 ALTER TABLE `spell` DISABLE KEYS */;
INSERT INTO `spell` (`Spell_Name`, `Cooldown`, `Description`) VALUES ('barrier',280,'Kerdizis 150 Aspida gia 3s'),('Flash',300,'Metakinisi akariea mexri mia apostasi 300 range'),('Ghost',255,'Trexis +30% pio grigora'),('Heal',360,'Kerdizis 250 zoi kai +5%taxitita kinishs'),('Ignite',350,'Kanis 200 pragmatiki zimia sto antipalo gia 4s'),('Teleport',400,'Thlemetaferese se mia alli perioxi toy map meta apo 3s');
/*!40000 ALTER TABLE `spell` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Spell_BEFORE_INSERT`
BEFORE INSERT ON `LoL_gdb`.`spell`
FOR EACH ROW
BEGIN
	if( new.Cooldown < 0) Then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `LoL_gdb`.`Spell_BEFORE_UPDATE`
BEFORE UPDATE ON `LoL_gdb`.`spell`
FOR EACH ROW
BEGIN
	if( new.Cooldown < 0) Then
		signal sqlstate '45000' set message_text = 'invalid data';
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping events for database 'lol_gdb'
--

--
-- Dumping routines for database 'lol_gdb'
--

--
-- Final view structure for view `challenger_picks`
--

/*!50001 DROP VIEW IF EXISTS `challenger_picks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `challenger_picks` AS select `game`.`id` AS `id`,`game`.`Creeps_killed` AS `Creeps_killed`,`game`.`Kills` AS `Kills`,`game`.`Deaths` AS `Deaths`,`game`.`Assists` AS `Assists`,`game`.`Duration` AS `Duration`,`game`.`Dates` AS `Dates`,`game`.`Team_side` AS `Team_side`,`game`.`Result` AS `Result`,`game`.`Position` AS `Position`,`game`.`Champ_Name` AS `Champ_Name`,`game`.`Player_Name` AS `Player_Name`,`game`.`Champ_Level` AS `Champ_Level`,`player`.`User_Name` AS `User_Name`,`player`.`Level` AS `Level`,`player`.`Rank` AS `Rank`,`player`.`Age` AS `Age` from (`game` join `player` on((`game`.`Player_Name` = `player`.`User_Name`))) where ((`player`.`Rank` = 'Master') or (`player`.`Rank` = 'Challenger')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `champion_ranking`
--

/*!50001 DROP VIEW IF EXISTS `champion_ranking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `champion_ranking` AS select avg(((`game`.`Kills` + `game`.`Assists`) / `game`.`Deaths`)) AS `KDA`,`game`.`Champ_Name` AS `Champion` from `game` group by `game`.`Champ_Name` order by avg(((`game`.`Kills` + `game`.`Assists`) / `game`.`Deaths`)) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `date_player_comb`
--

/*!50001 DROP VIEW IF EXISTS `date_player_comb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `date_player_comb` AS select distinct `game`.`Player_Name` AS `player_name`,`temp`.`dates` AS `dates` from (`game` join `dates_of_interest` `temp`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dates_of_interest`
--

/*!50001 DROP VIEW IF EXISTS `dates_of_interest`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dates_of_interest` AS select distinct `game`.`Dates` AS `dates` from `game` where (`game`.`Dates` >= '2018/11/01') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `matchups`
--

/*!50001 DROP VIEW IF EXISTS `matchups`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `matchups` AS select `g1`.`Champ_Name` AS `champ_red`,`g2`.`Champ_Name` AS `champ_blue`,`g1`.`Position` AS `Position`,`g1`.`Result` AS `result` from (`game` `g1` join `game` `g2`) where ((`g1`.`id` = `g2`.`id`) and (`g1`.`Position` = `g2`.`Position`) and (`g1`.`Champ_Name` <> `g2`.`Champ_Name`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-23 19:43:22
