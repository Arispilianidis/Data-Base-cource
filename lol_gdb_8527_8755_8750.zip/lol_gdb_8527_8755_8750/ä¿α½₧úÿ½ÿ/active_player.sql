/* briski tyos energoys pektes poy exoyn paizi toylaxiston ena game tis hmerominies pou periexontai sto dates_of_interest*/


select distinct player_name from game
where player_name not in(
	select player_name from 
		(select player_name, dates from date_player_comb 
		where (player_name, dates) 
		not in (select player_name,dates from game)) as temp);








