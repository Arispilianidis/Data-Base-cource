#epidoseis irwwn otan erxontai antimetopoi(sigekrimena darius vs nasus)
#mas endiaferei posa paixnidia kerdise o x_champ vs ton y_champ me tin proipo8esi oti briskontan 
#sto idio game_id kai itan sto idio position kai se antipales omades
drop table if exists G1;
create temporary table G1 as
select id,champ_name,team_side,position,result from game where champ_name='nasus';
select * from G1;

drop table if exists G2;
create temporary table G2 as
select id as id2,champ_name as ch_name,team_side as ts,position as pos,result as res from game where champ_name='darius';
select * from G2;

drop table if exists temp; 
create temporary table temp as
select * from G1  join G2  on (G1.id=G2.id2 and G1.position=G2.pos and G1.team_side != G2.ts);
select * from temp;

drop table if exists Wins;
create temporary table Wins as
select count(result) as wins from temp where result='win';
select * from Wins;

drop table if exists Loses;
create temporary table Loses as
select count(result) as loses from temp where result='lose';
select * from Loses;

drop table if exists Res;
create temporary table Res as
select (wins/(wins+loses+0.001)*100) as WinRate from (Wins Cross join Loses);#0.001-> gia na min diairesoume me 0
select * from Res;#to cross join den einai xronoboro dioti oi pinakes Wins kai Loses einai 1x1








