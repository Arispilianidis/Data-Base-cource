#oloi challenger pion champ paizoun pio sixna sto mid
drop table if exists temp;
create temporary table temp as
select Champ_Name,player_name from challenger_picks where position  = 'Mid';
select * from temp;


drop table if exists temp2;
create temporary table temp2 as
select player_name,champ_name,count(champ_name) as counts from temp
group by player_name,champ_name
order by counts desc;
select * from temp2;


drop table if exists temp3;
create temporary table temp3 as
select player_name,champ_name,max(counts) from temp2 group by player_name;
select player_name,champ_name from temp3;

