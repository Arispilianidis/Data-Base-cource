drop table if exists t;
create temporary table t as 
select avg((Kills+Assists)/Deaths) as KDA ,player_name as Player
from game
where Champ_Name = "veigar"
group by player_name;

select max(KDA) as KDA, Player
from t;
