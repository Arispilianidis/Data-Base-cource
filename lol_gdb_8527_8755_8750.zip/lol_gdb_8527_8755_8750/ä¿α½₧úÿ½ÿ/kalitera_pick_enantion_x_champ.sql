/*sto erothma theloyme na broyme pio n champion einai kalyteri enantion se champion_x
arxika dialegoyme apo thn opsi matchups ola se osa exei simetasxi o champion_x

select * from matchups where champ_red = 'Ahri';

kai epita kanoyme ena count sta win poy ekane o champion_y (afoy ton kanoyme group by)
enantia toy x;

from (select * from matchups where champ_red = 'Ahri') as giorgos
where result = 'lose'
group by champ_blue;

telos na ensomatonoyme dialegontaas pioys i pia einai h niosti kalyteri epilogi
dhladh exei simiosi tiw perissoteres nikes 
*/


SELECT DISTINCT  counts,champ_blue 
FROM (select count(result) as counts,champ_blue 
	from (select * from matchups where champ_red = 'Ahri') as giorgos where result = 'win'
	group by champ_blue) k1
WHERE 1 = (SELECT COUNT(DISTINCT counts) 
FROM (select count(result) as counts,champ_blue 
	from (select * from matchups where champ_red = 'Ahri') as mitsos where result = 'win'
	group by champ_blue) k2 
WHERE k1.counts <= k2.counts);



/*drop table if exists temp;
create temporary table temp as
select * from matchups where champ_red = 'Ahri';
select * from temp;

drop table if exists temp2;
create temporary table temp2 as
select count(result) as counts,champ_blue 
from (select * from matchups where champ_red = 'Ahri') as giorgos
where result = 'lose'
group by champ_blue;
select * from temp2;
*/


