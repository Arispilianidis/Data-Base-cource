# Create user admin that has all privileges in the DB from the server of the DB (localhost) and  from other servers
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'superpassword';
GRANT all privileges ON LoL_gdb.* TO 'admin'@'localhost';


# Create user coach that can perform select and insert queries in the DB
CREATE USER 'coach'@'localhost' IDENTIFIED BY 'coachpassword';
CREATE USER 'coach'@'%' IDENTIFIED BY 'coachpassword';
GRANT SELECT, INSERT ON LoL_gdb.* TO 'coach'@'localhost';
GRANT SELECT, INSERT ON LoL_gdb.* TO 'coach'@'%';

# Create user player that can perform select queries in the DB
CREATE USER 'player'@'localhost' IDENTIFIED BY 'playerpassword';
CREATE USER 'player'@'%' IDENTIFIED BY 'playerpassword';
GRANT SELECT ON LoL_gdb.* TO 'player'@'localhost';
GRANT SELECT ON LoL_gdb.* TO 'player'@'%';
